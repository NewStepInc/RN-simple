var rowTemplate = '<tr class="item-row"><td class="item-name"><div class="delete-wrapper"><textarea>Item Name</textarea><a class="delete-item">&times;</a></div></td><td><textarea class="unit-cost">$0</textarea></td><td><textarea class="quantity">0</textarea></td><td><span class="total-cost">0</span></td></tr>'
// import moment from 'moment';

function updateTotal(context) {
    var total = 0;
    $(context).closest('.invoice-container').find('.total-cost').each(function() {
        var price = $(this).html().replace('$', '');
        if (!isNaN(price)) {
            total += Number(price);
        };
    });

    $(context).closest('.invoice-container').find('.total').html('$' + total);
}

function updatePrice() {
    var $row = $(this).parents('.item-row');
    var price = $row.find('.unit-cost').val().replace('$', '') * $row.find('.quantity').val();

    isNaN(price) ? $row.find('.total-cost').html('N/A') : $row.find('.total-cost').html('$' + price);

    updateTotal(this);
}

function registerCostUpdate() {
    $('.unit-cost').blur(updatePrice);
    $('.quantity').blur(updatePrice);
}

function init() {

    $('.invoice-wrapper').on('click', 'input', function() {
        $(this).select();
    });

    $('.invoice-wrapper').on('click', '.add-row', function() {
        console.log('New rowing')
        var newRow = rowTemplate;

        $(this).closest('.invoice-container').find('.item-row:last').after(newRow);

        if ($('.delete').length > 0) {
            $('.delete').show();
        }

        registerCostUpdate();
    });

    console.log('Initting y')
    registerCostUpdate();

    $('.invoice-wrapper').on('click', '.delete', function() {
        $(this).parents('.item-row').remove();
        updateTotal();

        if ($('.delete').length < 2) {
            $('.delete').hide();
        }
    });

    $('.invoice-wrapper').on('click', '.cancel-logo', function() {
        $(this).closest('.invoice-container').find('.logo').removeClass('edit');
    });

    $('.invoice-wrapper').on('click', '.delete-logo', function() {
        $(this).closest('.invoice-container').find('.logo').remove();
    });

    $('.invoice-wrapper').on('click', '.change-logo', function() {
        $(this).closest('.invoice-container').find('.logo').addClass('edit');
        $(this).closest('.invoice-container').find('.logo-src').val($('.logo-image').attr('src'));
        $(this).closest('.invoice-container').find('.logo-image').select();
    });

    $('.invoice-wrapper').on('click', '.save-logo', function() {
        $(this).closest('.invoice-container').find('.logo-image').attr('src', $('.logo-src').val());
        $(this).closest('.invoice-container').find('.logo').removeClass('edit');
    });

    $('.invoice-date').val('April 4, 2016');
}

$(document).ready(init);